NeoGuard: completed 100-case synthetic EOS study

NICE 40; AAP 30; WHO 30. The original 18 vignettes are unchanged.
This archive contains all CSV tables, the synthetic dataset/reference
passages, measured raw role outcomes, protocols, hashes, environment
versions, integrity checks and final sentence/number change logs.
API-availability logs and duplicate role caches are excluded.
Source PDFs, real patient tables, credentials and demo files are excluded.
Guideline text remains attributed to its original publisher.

Use the eosRAG repository and docs/research/expanded100_protocol.md for
reproduction; model aliases are not immutable provider snapshots.
These are engineering measurements and not clinical validation.
